import React from "react";

export default function Panel(props) {
  return <div>{props.children}</div>;
}
