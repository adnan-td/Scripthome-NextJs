export const hostname = "https://scripthome.org";
// export const hostname = "http://localhost:3000";
