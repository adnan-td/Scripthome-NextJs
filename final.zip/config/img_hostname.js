export const imghost = "https://files.scripthome.org";
// export const imghost = "http://localhost:8000";
