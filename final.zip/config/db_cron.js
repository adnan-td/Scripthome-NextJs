// module.exports.dblink = "mysql://root@localhost:3306/scripthome";
module.exports.dblink = "mysql://sudhanshu_shome:!eX=R.QE]kyq@localhost:3306/sudhanshu_scripthome";
