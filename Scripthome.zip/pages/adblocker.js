import Modalmc from "../main-site/components/Error-Modal/AdBlocker-Modal/mc.component";

export default function Adblocker() {
  return (
    <div style={{ backgroundColor: "#000", height: "100vh", width: "100%" }}>
      <Modalmc />
    </div>
  );
}
